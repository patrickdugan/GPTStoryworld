﻿#!/usr/bin/env python3
"""Run 4-7 player social-reasoning simulation series.

The model extends the pValue/p2Value dynamics from the 3-agent prototype.
Outputs:
- summary JSON
- per-episode CSV
- event sample JSONL
"""

from __future__ import annotations

import argparse
import csv
import json
import random
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Dict, Iterable, List, Tuple

TRAITS: List[str] = [
    "loyalty",
    "reciprocity",
    "risk_tolerance",
    "promise_keeping",
]

ACTIONS: List[str] = [
    "join_coalition",
    "defect",
    "betray",
    "isolate",
    "death_ground",
]

ACTION_SIGNALS: Dict[str, Dict[str, float]] = {
    "join_coalition": {
        "loyalty": 0.08,
        "reciprocity": 0.07,
        "risk_tolerance": 0.02,
        "promise_keeping": 0.05,
    },
    "defect": {
        "loyalty": -0.10,
        "reciprocity": -0.12,
        "risk_tolerance": 0.03,
        "promise_keeping": -0.09,
    },
    "betray": {
        "loyalty": -0.19,
        "reciprocity": -0.21,
        "risk_tolerance": 0.06,
        "promise_keeping": -0.23,
    },
    "isolate": {
        "loyalty": -0.03,
        "reciprocity": -0.05,
        "risk_tolerance": -0.01,
        "promise_keeping": -0.02,
    },
    "death_ground": {
        "loyalty": 0.01,
        "reciprocity": -0.02,
        "risk_tolerance": 0.16,
        "promise_keeping": 0.04,
    },
}

GAIN = {
    "join_coalition": 0.08,
    "defect": 0.11,
    "betray": 0.17,
    "isolate": 0.03,
    "death_ground": 0.14,
}

RISK = {
    "join_coalition": 0.04,
    "defect": 0.08,
    "betray": 0.14,
    "isolate": 0.05,
    "death_ground": 0.18,
}

REPUTATION_COST = {
    "join_coalition": 0.01,
    "defect": 0.06,
    "betray": 0.13,
    "isolate": 0.03,
    "death_ground": 0.05,
}


def clip01(x: float) -> float:
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


@dataclass
class PlannedEvent:
    actor: str
    target: str
    action: str
    utility: float


class NAgentSocialState:
    def __init__(self, agents: List[str], seed: int) -> None:
        self.agents = agents
        rng = random.Random(seed)

        self.theta: Dict[str, Dict[str, float]] = {
            agent: {trait: clip01(0.5 + rng.uniform(-0.2, 0.2)) for trait in TRAITS}
            for agent in agents
        }

        self.p: Dict[Tuple[str, str, str], float] = {}
        for obs in agents:
            for tgt in agents:
                if obs == tgt:
                    continue
                for trait in TRAITS:
                    base = 0.5 + 0.25 * (self.theta[tgt][trait] - 0.5) + rng.uniform(-0.04, 0.04)
                    self.p[(obs, tgt, trait)] = clip01(base)

        self.p2: Dict[Tuple[str, str, str, str], float] = {}
        for obs in agents:
            for med in agents:
                if med == obs:
                    continue
                for tgt in agents:
                    if tgt == med:
                        continue
                    for trait in TRAITS:
                        base = self.p[(med, tgt, trait)] + rng.uniform(-0.05, 0.05)
                        self.p2[(obs, med, tgt, trait)] = clip01(base)

    def average_pair_trait(self, trait: str) -> float:
        vals = [
            value
            for (obs, tgt, key), value in self.p.items()
            if key == trait and obs != tgt
        ]
        return mean(vals) if vals else 0.5

    def average_meta_consistency(self) -> float:
        diffs = []
        for (obs, med, tgt, trait), value in self.p2.items():
            direct = self.p[(med, tgt, trait)]
            diffs.append(abs(value - direct))
        return 1.0 - mean(diffs) if diffs else 1.0

    def choose_target(self, agent: str) -> str:
        best_target = None
        best_score = float("-inf")
        for other in self.agents:
            if other == agent:
                continue
            score = (
                0.55 * (1.0 - self.p[(agent, other, "loyalty")])
                + 0.30 * (1.0 - self.p[(agent, other, "reciprocity")])
                + 0.15 * self.p[(agent, other, "risk_tolerance")]
            )
            if score > best_score:
                best_score = score
                best_target = other
        assert best_target is not None
        return best_target

    def utility(self, agent: str, target: str, action: str) -> float:
        rel = self.p[(agent, target, "reciprocity")]
        trust = self.p[(agent, target, "loyalty")]
        meta = self.p2.get((agent, target, agent, "promise_keeping"), trust)

        incoming_trust = mean(
            self.p[(other, agent, "loyalty")] for other in self.agents if other != agent
        )
        existential_pressure = clip01((0.45 - incoming_trust) * 2.0)

        coalition_bonus = 0.12 if action == "join_coalition" and trust > 0.55 else 0.0
        death_ground_bonus = 0.20 * existential_pressure if action == "death_ground" else 0.0
        betrayal_bonus = 0.16 * (1.0 - meta) if action == "betray" else 0.0

        return (
            1.12 * GAIN[action]
            + 0.96 * rel
            + 0.66 * meta
            + coalition_bonus
            + death_ground_bonus
            + betrayal_bonus
            - 1.00 * RISK[action]
            - 0.90 * REPUTATION_COST[action]
        )

    def ranked_actions(self, agent: str, target: str) -> List[Tuple[str, float]]:
        scores = [(action, self.utility(agent, target, action)) for action in ACTIONS]
        scores.sort(key=lambda item: item[1], reverse=True)
        return scores

    def apply_event(self, actor: str, target: str, action: str, alpha: float = 0.34, beta: float = 0.20) -> None:
        signals = ACTION_SIGNALS[action]

        # Direct belief update on actor from all observers.
        for obs in self.agents:
            if obs == actor:
                continue
            for trait in TRAITS:
                key = (obs, actor, trait)
                old = self.p[key]
                surprise = abs(signals[trait])
                alpha_eff = alpha * (1.0 + 1.3 * surprise)
                self.p[key] = clip01(old + alpha_eff * signals[trait])

        # Target-specific side effects for defection/betrayal events.
        if action in {"defect", "betray"}:
            for obs in self.agents:
                if obs == target:
                    continue
                risk_key = (obs, target, "risk_tolerance")
                rec_key = (obs, target, "reciprocity")
                self.p[risk_key] = clip01(self.p[risk_key] + 0.04)
                self.p[rec_key] = clip01(self.p[rec_key] - 0.03)

        # Meta-belief smoothing toward direct estimates.
        for obs in self.agents:
            for med in self.agents:
                if med == obs:
                    continue
                for tgt in self.agents:
                    if tgt == med:
                        continue
                    for trait in TRAITS:
                        key2 = (obs, med, tgt, trait)
                        direct = self.p[(med, tgt, trait)]
                        old2 = self.p2[key2]
                        self.p2[key2] = clip01((1.0 - beta) * old2 + beta * direct)

    def simulate_turn(self, rng: random.Random, epsilon: float) -> List[PlannedEvent]:
        order = list(self.agents)
        rng.shuffle(order)

        planned: List[PlannedEvent] = []
        for agent in order:
            target = self.choose_target(agent)
            ranked = self.ranked_actions(agent, target)
            if rng.random() < epsilon:
                action = rng.choice(ACTIONS)
                utility = dict(ranked)[action]
            else:
                action, utility = ranked[0]
            planned.append(PlannedEvent(actor=agent, target=target, action=action, utility=utility))

        for event in planned:
            self.apply_event(event.actor, event.target, event.action)

        return planned


def run_episode(n_agents: int, turns: int, seed: int, epsilon: float) -> Tuple[Dict[str, float], List[Dict[str, object]]]:
    agents = [f"P{i+1}" for i in range(n_agents)]
    rng = random.Random(seed)
    state = NAgentSocialState(agents=agents, seed=seed)

    action_counts: Counter[str] = Counter()
    event_rows: List[Dict[str, object]] = []

    for turn in range(1, turns + 1):
        events = state.simulate_turn(rng=rng, epsilon=epsilon)
        for event in events:
            action_counts[event.action] += 1
            event_rows.append(
                {
                    "turn": turn,
                    "actor": event.actor,
                    "target": event.target,
                    "action": event.action,
                    "utility": round(event.utility, 6),
                }
            )

    total_actions = sum(action_counts.values()) or 1

    final_loyalty = state.average_pair_trait("loyalty")
    final_reciprocity = state.average_pair_trait("reciprocity")
    final_promise = state.average_pair_trait("promise_keeping")

    episode_metrics: Dict[str, float] = {
        "n_agents": float(n_agents),
        "seed": float(seed),
        "turns": float(turns),
        "final_loyalty": final_loyalty,
        "final_reciprocity": final_reciprocity,
        "final_promise_keeping": final_promise,
        "meta_consistency": state.average_meta_consistency(),
        "coalition_rate": action_counts["join_coalition"] / total_actions,
        "defect_rate": action_counts["defect"] / total_actions,
        "betray_rate": action_counts["betray"] / total_actions,
        "isolate_rate": action_counts["isolate"] / total_actions,
        "death_ground_rate": action_counts["death_ground"] / total_actions,
        "instability_index": (action_counts["defect"] + action_counts["betray"]) / total_actions,
        "cohesion_index": (final_loyalty + final_reciprocity) / 2.0,
    }

    return episode_metrics, event_rows


def aggregate_group(group: Iterable[Dict[str, float]]) -> Dict[str, float]:
    rows = list(group)
    if not rows:
        return {}

    def m(key: str) -> float:
        return mean(row[key] for row in rows)

    return {
        "episodes": float(len(rows)),
        "final_loyalty": m("final_loyalty"),
        "final_reciprocity": m("final_reciprocity"),
        "final_promise_keeping": m("final_promise_keeping"),
        "meta_consistency": m("meta_consistency"),
        "coalition_rate": m("coalition_rate"),
        "defect_rate": m("defect_rate"),
        "betray_rate": m("betray_rate"),
        "isolate_rate": m("isolate_rate"),
        "death_ground_rate": m("death_ground_rate"),
        "instability_index": m("instability_index"),
        "cohesion_index": m("cohesion_index"),
    }


def write_episode_csv(rows: List[Dict[str, float]], path: Path) -> None:
    if not rows:
        return
    headers = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=headers)
        writer.writeheader()
        writer.writerows(rows)


def write_event_sample_jsonl(rows: List[Dict[str, object]], path: Path, max_rows: int) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows[:max_rows]:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run pValue/p2Value N-agent simulation series.")
    parser.add_argument("--min-agents", type=int, default=4)
    parser.add_argument("--max-agents", type=int, default=7)
    parser.add_argument("--episodes", type=int, default=24)
    parser.add_argument("--turns", type=int, default=12)
    parser.add_argument("--seed", type=int, default=20260206)
    parser.add_argument("--epsilon", type=float, default=0.08)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("C:/projects/GPTStoryworld/social-reasoning/outputs"),
    )
    parser.add_argument("--sample-events", type=int, default=600)
    args = parser.parse_args()

    if args.min_agents < 3:
        raise ValueError("--min-agents must be >= 3")
    if args.max_agents < args.min_agents:
        raise ValueError("--max-agents must be >= --min-agents")

    args.out_dir.mkdir(parents=True, exist_ok=True)

    episode_rows: List[Dict[str, float]] = []
    sampled_events: List[Dict[str, object]] = []

    for n_agents in range(args.min_agents, args.max_agents + 1):
        for episode in range(args.episodes):
            seed = args.seed + (n_agents * 1000) + episode
            metrics, events = run_episode(
                n_agents=n_agents,
                turns=args.turns,
                seed=seed,
                epsilon=args.epsilon,
            )
            row = {
                "n_agents": int(metrics["n_agents"]),
                "episode": episode,
                "seed": int(metrics["seed"]),
                "turns": int(metrics["turns"]),
                "final_loyalty": round(metrics["final_loyalty"], 6),
                "final_reciprocity": round(metrics["final_reciprocity"], 6),
                "final_promise_keeping": round(metrics["final_promise_keeping"], 6),
                "meta_consistency": round(metrics["meta_consistency"], 6),
                "coalition_rate": round(metrics["coalition_rate"], 6),
                "defect_rate": round(metrics["defect_rate"], 6),
                "betray_rate": round(metrics["betray_rate"], 6),
                "isolate_rate": round(metrics["isolate_rate"], 6),
                "death_ground_rate": round(metrics["death_ground_rate"], 6),
                "instability_index": round(metrics["instability_index"], 6),
                "cohesion_index": round(metrics["cohesion_index"], 6),
            }
            episode_rows.append(row)

            for event in events[:4]:
                sampled_events.append(
                    {
                        "n_agents": n_agents,
                        "episode": episode,
                        "seed": seed,
                        **event,
                    }
                )

    grouped: Dict[int, List[Dict[str, float]]] = {}
    for row in episode_rows:
        grouped.setdefault(int(row["n_agents"]), []).append(row)

    by_group = {str(k): aggregate_group(v) for k, v in grouped.items()}

    summary = {
        "config": {
            "min_agents": args.min_agents,
            "max_agents": args.max_agents,
            "episodes": args.episodes,
            "turns": args.turns,
            "seed": args.seed,
            "epsilon": args.epsilon,
        },
        "by_n_agents": by_group,
    }

    json_path = args.out_dir / f"n_agent_series_{args.min_agents}_{args.max_agents}_summary.json"
    csv_path = args.out_dir / f"n_agent_series_{args.min_agents}_{args.max_agents}_episodes.csv"
    sample_path = args.out_dir / f"n_agent_series_{args.min_agents}_{args.max_agents}_events_sample.jsonl"

    json_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_episode_csv(episode_rows, csv_path)
    write_event_sample_jsonl(sampled_events, sample_path, max_rows=args.sample_events)

    print(f"wrote {json_path}")
    print(f"wrote {csv_path}")
    print(f"wrote {sample_path}")


if __name__ == "__main__":
    main()
